using System;
using System.Collections.Generic;
using Top.Api.Util;

namespace Top.Api.Request
{
    /// <summary>
    /// TOP API: taobao.trade.ordersku.update
    /// </summary>
    public class TradeOrderskuUpdateRequest : BaseTopRequest<Top.Api.Response.TradeOrderskuUpdateResponse>
    {
        /// <summary>
        /// 子订单编号（对于单笔订单的交易可以传交易编号）。
        /// </summary>
        public Nullable<long> Oid { get; set; }

        /// <summary>
        /// 销售属性编号，可以通过taobao.item.skus.get获取订单对应的商品的所有销售属性。
        /// </summary>
        public Nullable<long> SkuId { get; set; }

        /// <summary>
        /// 销售属性组合串，格式：p1:v1;p2:v2，如：1627207:28329;20509:28314。可以通过taobao.item.skus.get获取订单对应的商品的所有销售属性。
        /// </summary>
        public string SkuProps { get; set; }

        #region ITopRequest Members

        public override string GetApiName()
        {
            return "taobao.trade.ordersku.update";
        }

        public override IDictionary<string, string> GetParameters()
        {
            TopDictionary parameters = new TopDictionary();
            parameters.Add("oid", this.Oid);
            parameters.Add("sku_id", this.SkuId);
            parameters.Add("sku_props", this.SkuProps);
            if (this.otherParams != null)
            {
                parameters.AddAll(this.otherParams);
            }
            return parameters;
        }

        public override void Validate()
        {
            RequestValidator.ValidateRequired("oid", this.Oid);
        }

        #endregion
    }
}
