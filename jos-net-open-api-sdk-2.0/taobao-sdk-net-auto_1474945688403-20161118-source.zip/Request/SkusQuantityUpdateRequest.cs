using System;
using System.Collections.Generic;
using Top.Api.Util;

namespace Top.Api.Request
{
    /// <summary>
    /// TOP API: taobao.skus.quantity.update
    /// </summary>
    public class SkusQuantityUpdateRequest : BaseTopRequest<Top.Api.Response.SkusQuantityUpdateResponse>
    {
        /// <summary>
        /// 商品数字ID，必填参数
        /// </summary>
        public Nullable<long> NumIid { get; set; }

        /// <summary>
        /// 特殊可选，skuIdQuantities为空的时候用该字段通过outerId来指定sku和其库存修改值。格式为outerId:库存修改值;outerId:库存修改值。当skuIdQuantities不为空的时候该字段失效。当一个outerId对应多个sku时，所有匹配到的sku都会被修改库存。最多支持20个SKU同时修改。
        /// </summary>
        public string OuteridQuantities { get; set; }

        /// <summary>
        /// sku库存批量修改入参，用于指定一批sku和每个sku的库存修改值，特殊可填。格式为skuId:库存修改值;skuId:库存修改值。最多支持20个SKU同时修改。
        /// </summary>
        public string SkuidQuantities { get; set; }

        /// <summary>
        /// 库存更新方式，可选。1为全量更新，2为增量更新。如果不填，默认为全量更新。当选择全量更新时，如果库存更新值传入的是负数，会出错并返回错误码；当选择增量更新时，如果库存更新值为负数且绝对值大于当前库存，则sku库存会设置为0.
        /// </summary>
        public Nullable<long> Type { get; set; }

        #region ITopRequest Members

        public override string GetApiName()
        {
            return "taobao.skus.quantity.update";
        }

        public override IDictionary<string, string> GetParameters()
        {
            TopDictionary parameters = new TopDictionary();
            parameters.Add("num_iid", this.NumIid);
            parameters.Add("outerid_quantities", this.OuteridQuantities);
            parameters.Add("skuid_quantities", this.SkuidQuantities);
            parameters.Add("type", this.Type);
            if (this.otherParams != null)
            {
                parameters.AddAll(this.otherParams);
            }
            return parameters;
        }

        public override void Validate()
        {
            RequestValidator.ValidateRequired("num_iid", this.NumIid);
        }

        #endregion
    }
}
