using System;
using System.Collections.Generic;
using Top.Api.Util;

namespace Top.Api.Request
{
    /// <summary>
    /// TOP API: taobao.logistics.orders.get
    /// </summary>
    public class LogisticsOrdersGetRequest : BaseTopRequest<Top.Api.Response.LogisticsOrdersGetResponse>
    {
        /// <summary>
        /// 买家昵称
        /// </summary>
        public string BuyerNick { get; set; }

        /// <summary>
        /// 创建时间结束
        /// </summary>
        public Nullable<DateTime> EndCreated { get; set; }

        /// <summary>
        /// 需返回的字段列表.可选值:Shipping 物流数据结构中的以下字段: <br>  tid,order_code,seller_nick,buyer_nick,delivery_start, delivery_end,out_sid,item_title,receiver_name, created,modified,status,type,freight_payer,seller_confirm,company_name,sub_tids,is_spilt；<br>多个字段之间用","分隔。如tid,seller_nick,buyer_nick,delivery_start。
        /// </summary>
        public string Fields { get; set; }

        /// <summary>
        /// 谁承担运费.可选值:buyer(买家),seller(卖家).如:buyer
        /// </summary>
        public string FreightPayer { get; set; }

        /// <summary>
        /// 页码.该字段没传 或 值<1 ,则默认page_no为1
        /// </summary>
        public Nullable<long> PageNo { get; set; }

        /// <summary>
        /// 每页条数.该字段没传 或 值<1 ,则默认page_size为40
        /// </summary>
        public Nullable<long> PageSize { get; set; }

        /// <summary>
        /// 收货人姓名
        /// </summary>
        public string ReceiverName { get; set; }

        /// <summary>
        /// 卖家是否发货.可选值:yes(是),no(否).如:yes
        /// </summary>
        public string SellerConfirm { get; set; }

        /// <summary>
        /// 创建时间开始
        /// </summary>
        public Nullable<DateTime> StartCreated { get; set; }

        /// <summary>
        /// 物流状态.查看数据结构 Shipping 中的status字段.
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// 交易ID.如果加入tid参数的话,不用传其他的参数,若传入tid：非拆单场景，仅会返回一条物流订单信息；拆单场景，会返回多条物流订单信息
        /// </summary>
        public Nullable<long> Tid { get; set; }

        /// <summary>
        /// 物流方式.可选值:post(平邮),express(快递),ems(EMS).如:post
        /// </summary>
        public string Type { get; set; }

        #region ITopRequest Members

        public override string GetApiName()
        {
            return "taobao.logistics.orders.get";
        }

        public override IDictionary<string, string> GetParameters()
        {
            TopDictionary parameters = new TopDictionary();
            parameters.Add("buyer_nick", this.BuyerNick);
            parameters.Add("end_created", this.EndCreated);
            parameters.Add("fields", this.Fields);
            parameters.Add("freight_payer", this.FreightPayer);
            parameters.Add("page_no", this.PageNo);
            parameters.Add("page_size", this.PageSize);
            parameters.Add("receiver_name", this.ReceiverName);
            parameters.Add("seller_confirm", this.SellerConfirm);
            parameters.Add("start_created", this.StartCreated);
            parameters.Add("status", this.Status);
            parameters.Add("tid", this.Tid);
            parameters.Add("type", this.Type);
            if (this.otherParams != null)
            {
                parameters.AddAll(this.otherParams);
            }
            return parameters;
        }

        public override void Validate()
        {
            RequestValidator.ValidateRequired("fields", this.Fields);
            RequestValidator.ValidateMaxValue("page_size", this.PageSize, 100);
        }

        #endregion
    }
}
